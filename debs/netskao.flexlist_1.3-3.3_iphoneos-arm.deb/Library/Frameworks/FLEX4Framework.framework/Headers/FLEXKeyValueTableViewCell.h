//
//  FLEXKeyValueTableViewCell.h
//  FLEX
//
//  Created by Tanner Bennett on 1/23/20.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXTableViewCell.h"

@interface FLEXKeyValueTableViewCell : FLEXTableViewCell

@end
