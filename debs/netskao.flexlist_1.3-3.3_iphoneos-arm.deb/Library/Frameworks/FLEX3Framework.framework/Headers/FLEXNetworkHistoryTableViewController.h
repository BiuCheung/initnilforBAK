//
//  FLEXNetworkHistoryTableViewController.h
//  Flipboard
//
//  Created by Ryan Olson on 2/8/15.
//  Copyright (c) 2015 Flipboard. All rights reserved.
//

#import "FLEXTableViewController.h"
#import "FLEXGlobalsEntry.h"

@interface FLEXNetworkHistoryTableViewController : FLEXTableViewController <FLEXGlobalsEntry>

@end
