//
//  FLEXCookiesTableViewController.h
//  FLEX
//
//  Created by Rich Robinson on 19/10/2015.
//  Copyright © 2015 Flipboard. All rights reserved.
//

#import "FLEXGlobalsEntry.h"
#import "FLEXTableViewController.h"

@interface FLEXCookiesTableViewController : FLEXTableViewController <FLEXGlobalsEntry>

@end
