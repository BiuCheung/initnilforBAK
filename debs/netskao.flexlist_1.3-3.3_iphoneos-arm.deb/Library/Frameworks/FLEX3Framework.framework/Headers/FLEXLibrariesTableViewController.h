//
//  FLEXLibrariesTableViewController.h
//  Flipboard
//
//  Created by Ryan Olson on 2014-05-02.
//  Copyright (c) 2014 Flipboard. All rights reserved.
//

#import "FLEXTableViewController.h"
#import "FLEXGlobalsEntry.h"

@interface FLEXLibrariesTableViewController : FLEXTableViewController <FLEXGlobalsEntry>

@end
