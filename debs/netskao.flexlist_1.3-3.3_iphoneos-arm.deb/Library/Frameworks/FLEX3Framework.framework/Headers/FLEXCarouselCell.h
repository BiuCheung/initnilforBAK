//
//  FLEXCarouselCell.h
//  FLEX
//
//  Created by Tanner Bennett on 7/17/19.
//  Copyright © 2019 Flipboard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FLEXCarouselCell : UICollectionViewCell

@property (nonatomic, copy) NSString *title;

@end
